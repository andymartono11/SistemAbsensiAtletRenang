namespace SwimmingAttendance.Models
{
    public class Absensi
    {
        public int AbsensiId { get; set; }
        public int SesiId { get; set; }
        public int AtletId { get; set; }
        public string Status { get; set; } = "Hadir";
        public string? Catatan { get; set; }
    }
}