using System;

namespace SwimmingAttendance.Models
{
    public class Atlet
    {
        public int AtletId { get; set; }
        public string Nama { get; set; } = string.Empty;
        public DateTime TanggalLahir { get; set; } = DateTime.Today;
        public int KelompokId { get; set; }
        public string? NomorHP { get; set; }
        public DateTime TanggalBergabung { get; set; } = DateTime.Today;
        public bool IsActive { get; set; } = true;

        // Hanya untuk tampilan di DataGrid (diisi dari hasil JOIN)
        public string NamaKelompok { get; set; } = string.Empty;
        public string StatusText => IsActive ? "Aktif" : "Nonaktif";
    }
}