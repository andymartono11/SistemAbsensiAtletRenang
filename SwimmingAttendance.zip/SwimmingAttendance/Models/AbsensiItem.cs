namespace SwimmingAttendance.Models
{
    /// <summary>
    /// Helper untuk tampilan di DataGrid absensi.
    /// Setiap baris = 1 atlet + status + catatan.
    /// </summary>
    public class AbsensiItem
    {
        public int AtletId { get; set; }
        public string NamaAtlet { get; set; } = string.Empty;

        public string Status { get; set; } = "Hadir";
        public string? Catatan { get; set; }

        // Jika sudah pernah disimpan, simpan AbsensiId-nya untuk UPDATE
        public int? AbsensiId { get; set; }

        public string[] StatusOptions { get; } = { "Hadir", "Izin", "Sakit", "Alpha" };
    }
}