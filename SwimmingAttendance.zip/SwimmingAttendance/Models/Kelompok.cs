namespace SwimmingAttendance.Models
{
    public class Kelompok
    {
        public int KelompokId { get; set; }
        public string NamaKelompok { get; set; } = string.Empty;
        public string? Deskripsi { get; set; }
        public bool IsActive { get; set; } = true;

        // Hanya untuk tampilan di DataGrid
        public string StatusText => IsActive ? "Aktif" : "Nonaktif";
    }
}