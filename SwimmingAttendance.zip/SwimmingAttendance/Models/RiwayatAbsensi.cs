using System;

namespace SwimmingAttendance.Models
{
    public class RiwayatAbsensi
    {
        public DateTime Tanggal { get; set; }
        public string NamaKelompok { get; set; } = string.Empty;
        public string JamLatihan { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string? Catatan { get; set; }
    }
}