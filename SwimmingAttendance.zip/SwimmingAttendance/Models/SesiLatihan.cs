using System;

namespace SwimmingAttendance.Models
{
    public class SesiLatihan
    {
        public int SesiId { get; set; }
        public int JadwalId { get; set; }
        public DateTime Tanggal { get; set; }

        // Untuk tampilan (diisi dari JOIN)
        public string NamaKelompok { get; set; } = string.Empty;
        public string Hari { get; set; } = string.Empty;
        public TimeSpan JamMulai { get; set; }
        public TimeSpan JamSelesai { get; set; }

        public string JamMulaiText => JamMulai.ToString(@"hh\:mm");
        public string JamSelesaiText => JamSelesai.ToString(@"hh\:mm");
        public string Judul => $"{NamaKelompok} - {Tanggal:dd/MM/yyyy} ({JamMulaiText} - {JamSelesaiText})";
    }
}