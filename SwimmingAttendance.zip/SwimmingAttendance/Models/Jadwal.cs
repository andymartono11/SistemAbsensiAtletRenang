using System;

namespace SwimmingAttendance.Models
{
    public class Jadwal
    {
        public int JadwalId { get; set; }
        public int KelompokId { get; set; }
        public string Hari { get; set; } = string.Empty;
        public TimeSpan JamMulai { get; set; }
        public TimeSpan JamSelesai { get; set; }
        public bool IsActive { get; set; } = true;

        // Hanya untuk tampilan
        public string NamaKelompok { get; set; } = string.Empty;
        public string JamMulaiText => JamMulai.ToString(@"hh\:mm");
        public string JamSelesaiText => JamSelesai.ToString(@"hh\:mm");
        public string StatusText => IsActive ? "Aktif" : "Nonaktif";

        // BARU: dipakai dropdown di halaman Absensi
        public string Judul => $"{NamaKelompok} - {Hari} ({JamMulaiText} - {JamSelesaiText})";
    }
}