using System;

namespace SwimmingAttendance.Models
{
    public class RekapItem
    {
        public int AtletId { get; set; }
        public string Nama { get; set; } = string.Empty;
        public int Hadir { get; set; }
        public int Izin { get; set; }
        public int Sakit { get; set; }
        public int Alpha { get; set; }

        public int Total => Hadir + Izin + Sakit + Alpha;
        public string PersentaseText => Total == 0 ? "0%" : (int)Math.Round((double)Hadir / Total * 100) + "%";
    }
}