// ViewModels/LoginViewModel.cs
using System;
using System.Windows.Input;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Models;
using SwimmingAttendance.Services;

namespace SwimmingAttendance.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly AuthenticationService _authService = new AuthenticationService();

        private string _username = string.Empty;
        public string Username
        {
            get => _username;
            set => SetProperty(ref _username, value);
        }

        private string _password = string.Empty;
        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        private string _errorMessage = string.Empty;
        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        private bool _isLoading;
        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                if (SetProperty(ref _isLoading, value))
                    OnPropertyChanged(nameof(LoginButtonText));
            }
        }

        public string LoginButtonText => IsLoading ? "Memproses..." : "Login";

        /// <summary>
        /// Dipanggil saat login berhasil. View (code-behind) yang menangani pergantian window.
        /// </summary>
        public event Action<User>? LoginSucceeded;

        public ICommand LoginCommand { get; }

        public LoginViewModel()
        {
            // CanExecute mencegah tombol diklik dua kali saat sedang loading
            LoginCommand = new RelayCommand(_ => ExecuteLogin(), _ => !IsLoading);
        }

        private void ExecuteLogin()
        {
            ErrorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            {
                ErrorMessage = "Username dan password wajib diisi.";
                return;
            }

            IsLoading = true;
            try
            {
                var user = _authService.Login(Username.Trim(), Password, out string error);

                if (user == null)
                {
                    ErrorMessage = error;
                    Password = string.Empty;
                    return;
                }

                LoginSucceeded?.Invoke(user);
            }
            catch (Exception)
            {
                ErrorMessage = "Terjadi kesalahan saat masuk. Silakan coba lagi.";
            }
            finally
            {
                IsLoading = false;
            }
        }
    }
}