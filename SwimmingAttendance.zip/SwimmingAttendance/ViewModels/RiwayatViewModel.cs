using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class RiwayatViewModel : ViewModelBase
    {
        private readonly RiwayatRepository _repo = new RiwayatRepository();
        private readonly AtletRepository _atletRepo = new AtletRepository();

        private ObservableCollection<Atlet> _atletList = new ObservableCollection<Atlet>();
        public ObservableCollection<Atlet> AtletList
        {
            get => _atletList;
            set => SetProperty(ref _atletList, value);
        }

        private Atlet? _selectedAtlet;
        public Atlet? SelectedAtlet
        {
            get => _selectedAtlet;
            set { if (SetProperty(ref _selectedAtlet, value)) LoadData(); }
        }

        public List<string> BulanOptions { get; } = new List<string> { "Semua" };
        private string _selectedBulan = "Semua";
        public string SelectedBulan
        {
            get => _selectedBulan;
            set { if (SetProperty(ref _selectedBulan, value)) LoadData(); }
        }

        public List<string> TahunOptions { get; } = new List<string> { "Semua" };
        private string _selectedTahun = "Semua";
        public string SelectedTahun
        {
            get => _selectedTahun;
            set { if (SetProperty(ref _selectedTahun, value)) LoadData(); }
        }

        private ObservableCollection<RiwayatAbsensi> _data = new ObservableCollection<RiwayatAbsensi>();
        public ObservableCollection<RiwayatAbsensi> Data
        {
            get => _data;
            set => SetProperty(ref _data, value);
        }

        private bool _isEmpty;
        public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

        // Ringkasan
        private string _summaryNama = "-";
        public string SummaryNama { get => _summaryNama; set => SetProperty(ref _summaryNama, value); }

        private string _summaryKelompok = "-";
        public string SummaryKelompok { get => _summaryKelompok; set => SetProperty(ref _summaryKelompok, value); }

        private string _summaryHadir = "-";
        public string SummaryHadir { get => _summaryHadir; set => SetProperty(ref _summaryHadir, value); }

        private string _summaryPersentase = "-";
        public string SummaryPersentase { get => _summaryPersentase; set => SetProperty(ref _summaryPersentase, value); }

        public RiwayatViewModel()
        {
            AtletList = new ObservableCollection<Atlet>(_atletRepo.GetAll(null, null, null));

            foreach (var b in TanggalHelper.NamaBulan) BulanOptions.Add(b);
            foreach (var t in _repo.GetTahunList()) TahunOptions.Add(t.ToString());

            LoadData();
        }

        public void LoadData()
        {
            if (SelectedAtlet == null)
            {
                Data = new ObservableCollection<RiwayatAbsensi>();
                IsEmpty = true;
                SummaryNama = "-"; SummaryKelompok = "-"; SummaryHadir = "-"; SummaryPersentase = "-";
                return;
            }

            int? bulan = SelectedBulan == "Semua" ? null : TanggalHelper.BulanDariNama(SelectedBulan);
            int? tahun = int.TryParse(SelectedTahun, out int t) ? t : (int?)null;

            try
            {
                var list = _repo.GetRiwayat(SelectedAtlet.AtletId, bulan, tahun);
                Data = new ObservableCollection<RiwayatAbsensi>(list);

                int hadir = list.Count(x => x.Status == "Hadir");
                SummaryNama = SelectedAtlet.Nama;
                SummaryKelompok = SelectedAtlet.NamaKelompok;
                SummaryHadir = $"{hadir} dari {list.Count} sesi";
                SummaryPersentase = list.Count == 0 ? "0%" : (int)Math.Round((double)hadir / list.Count * 100) + "%";
            }
            catch (SqlException)
            {
                MessageBoxHelper.ShowError("Gagal memuat riwayat absensi.");
            }

            IsEmpty = Data.Count == 0;
        }
    }
}