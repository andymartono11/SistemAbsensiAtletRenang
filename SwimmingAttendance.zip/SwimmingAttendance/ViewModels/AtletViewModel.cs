using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class AtletViewModel : ViewModelBase
    {
        private readonly AtletRepository _atletRepo = new AtletRepository();
        private readonly KelompokRepository _kelompokRepo = new KelompokRepository();

        private ObservableCollection<Atlet> _data = new ObservableCollection<Atlet>();
        public ObservableCollection<Atlet> Data
        {
            get => _data;
            set => SetProperty(ref _data, value);
        }

        private bool _isEmpty;
        public bool IsEmpty
        {
            get => _isEmpty;
            set => SetProperty(ref _isEmpty, value);
        }

        private ObservableCollection<Kelompok> _kelompokList = new ObservableCollection<Kelompok>();
        public ObservableCollection<Kelompok> KelompokList
        {
            get => _kelompokList;
            set => SetProperty(ref _kelompokList, value);
        }

        private ObservableCollection<Kelompok> _filterKelompokList = new ObservableCollection<Kelompok>();
        public ObservableCollection<Kelompok> FilterKelompokList
        {
            get => _filterKelompokList;
            set => SetProperty(ref _filterKelompokList, value);
        }

        public List<string> StatusOptions { get; } = new List<string> { "Semua", "Aktif", "Nonaktif" };

        private Atlet _selected = new Atlet();
        public Atlet Selected
        {
            get => _selected;
            set
            {
                if (SetProperty(ref _selected, value))
                    OnPropertyChanged(nameof(IsEditMode));
            }
        }

        public bool IsEditMode => Selected != null && Selected.AtletId > 0;

        private string _searchNama = string.Empty;
        public string SearchNama
        {
            get => _searchNama;
            set { if (SetProperty(ref _searchNama, value)) LoadData(); }
        }

        private int _filterKelompokId;
        public int FilterKelompokId
        {
            get => _filterKelompokId;
            set { if (SetProperty(ref _filterKelompokId, value)) LoadData(); }
        }

        private string _filterStatus = "Semua";
        public string FilterStatus
        {
            get => _filterStatus;
            set { if (SetProperty(ref _filterStatus, value)) LoadData(); }
        }

        public ICommand NewCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand DeleteCommand { get; }

        public AtletViewModel()
        {
            NewCommand = new RelayCommand(_ => Selected = new Atlet());
            SaveCommand = new RelayCommand(_ => Save());
            DeleteCommand = new RelayCommand(_ => Delete());
            LoadData();
        }

        public void LoadData()
        {
            bool? aktif = FilterStatus == "Aktif" ? true : FilterStatus == "Nonaktif" ? false : (bool?)null;
            int? kelompokId = FilterKelompokId == 0 ? (int?)null : FilterKelompokId;

            Data = new ObservableCollection<Atlet>(_atletRepo.GetAll(SearchNama, kelompokId, aktif));
            IsEmpty = Data.Count == 0;

            var semua = _kelompokRepo.GetAll();
            KelompokList = new ObservableCollection<Kelompok>(semua);

            var untukFilter = new ObservableCollection<Kelompok> { new Kelompok { KelompokId = 0, NamaKelompok = "Semua Kelompok" } };
            foreach (var k in semua) untukFilter.Add(k);
            FilterKelompokList = untukFilter;
        }

        private void Save()
        {
            if (Selected == null) return;
            if (string.IsNullOrWhiteSpace(Selected.Nama))
            {
                MessageBoxHelper.ShowError("Nama atlet wajib diisi.");
                return;
            }
            if (Selected.KelompokId == 0)
            {
                MessageBoxHelper.ShowError("Kelompok wajib dipilih.");
                return;
            }

            try
            {
                if (IsEditMode) _atletRepo.Update(Selected);
                else _atletRepo.Insert(Selected);

                MessageBoxHelper.ShowSuccess(IsEditMode ? "Data berhasil diperbarui." : "Data berhasil ditambahkan.");
                Selected = new Atlet();
                LoadData();
            }
            catch (SqlException)
            {
                MessageBoxHelper.ShowError("Terjadi kesalahan saat menyimpan data.");
            }
        }

        private void Delete()
        {
            if (!IsEditMode) return;
            if (!MessageBoxHelper.Confirm($"Hapus atlet '{Selected.Nama}'?")) return;

            try
            {
                _atletRepo.Delete(Selected.AtletId);
                MessageBoxHelper.ShowSuccess("Data berhasil dihapus.");
                Selected = new Atlet();
                LoadData();
            }
            catch (SqlException)
            {
                MessageBoxHelper.ShowError("Data tidak dapat dihapus karena masih memiliki riwayat absensi.");
            }
        }
    }
}