using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class AbsensiViewModel : ViewModelBase
    {
        private readonly AbsensiRepository _repo = new AbsensiRepository();

        private ObservableCollection<Jadwal> _jadwalList = new ObservableCollection<Jadwal>();
        public ObservableCollection<Jadwal> JadwalList
        {
            get => _jadwalList;
            set => SetProperty(ref _jadwalList, value);
        }

        private Jadwal? _selectedJadwal;
        public Jadwal? SelectedJadwal
        {
            get => _selectedJadwal;
            set => SetProperty(ref _selectedJadwal, value);
        }

        private DateTime _tanggalAbsensi = DateTime.Today;
        public DateTime TanggalAbsensi
        {
            get => _tanggalAbsensi;
            set => SetProperty(ref _tanggalAbsensi, value);
        }

        private SesiLatihan? _sesiAktif;
        public SesiLatihan? SesiAktif
        {
            get => _sesiAktif;
            set => SetProperty(ref _sesiAktif, value);
        }

        private ObservableCollection<AbsensiItem> _items = new ObservableCollection<AbsensiItem>();
        public ObservableCollection<AbsensiItem> Items
        {
            get => _items;
            set => SetProperty(ref _items, value);
        }

        private bool _isEmpty;
        public bool IsEmpty
        {
            get => _isEmpty;
            set => SetProperty(ref _isEmpty, value);
        }

        private bool _sesiLoaded;
        public bool SesiLoaded
        {
            get => _sesiLoaded;
            set => SetProperty(ref _sesiLoaded, value);
        }

        public ICommand LoadSesiCommand { get; }
        public ICommand SimpanCommand { get; }

        public AbsensiViewModel()
        {
            LoadSesiCommand = new RelayCommand(_ => LoadSesi());
            SimpanCommand = new RelayCommand(_ => Simpan());
            LoadJadwal();
        }

        private void LoadJadwal()
        {
            JadwalList = new ObservableCollection<Jadwal>(_repo.GetJadwalAktif());
        }

        private void LoadSesi()
        {
            if (SelectedJadwal == null)
            {
                MessageBoxHelper.ShowError("Pilih jadwal terlebih dahulu.");
                return;
            }

            try
            {
                SesiAktif = _repo.GetOrCreateSesi(SelectedJadwal.JadwalId, TanggalAbsensi);
                Items = new ObservableCollection<AbsensiItem>(
                    _repo.GetAtletDenganAbsensi(SelectedJadwal.KelompokId, SesiAktif.SesiId));
                IsEmpty = Items.Count == 0;
                SesiLoaded = true;

                if (IsEmpty)
                    MessageBoxHelper.ShowError("Tidak ada atlet aktif di kelompok ini.");
            }
            catch (SqlException)
            {
                MessageBoxHelper.ShowError("Gagal memuat sesi latihan.");
            }
        }

        private void Simpan()
        {
            if (SesiAktif == null || Items.Count == 0) return;

            try
            {
                _repo.SimpanAbsensi(SesiAktif.SesiId, new System.Collections.Generic.List<AbsensiItem>(Items));
                MessageBoxHelper.ShowSuccess("Absensi berhasil disimpan.");
                // Reload agar AbsensiId tersimpan (untuk edit selanjutnya)
                LoadSesi();
            }
            catch (SqlException)
            {
                MessageBoxHelper.ShowError("Terjadi kesalahan saat menyimpan absensi.");
            }
        }
    }
}