using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class JadwalViewModel : ViewModelBase
    {
        private readonly JadwalRepository _repo = new JadwalRepository();
        private readonly KelompokRepository _kelompokRepo = new KelompokRepository();

        private ObservableCollection<Jadwal> _data = new ObservableCollection<Jadwal>();
        public ObservableCollection<Jadwal> Data { get => _data; set => SetProperty(ref _data, value); }

        private bool _isEmpty;
        public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

        private ObservableCollection<Kelompok> _kelompokList = new ObservableCollection<Kelompok>();
        public ObservableCollection<Kelompok> KelompokList { get => _kelompokList; set => SetProperty(ref _kelompokList, value); }

        public List<string> ListHari { get; } = new List<string> { "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu" };

        private Jadwal _selected = new Jadwal();
        public Jadwal Selected
        {
            get => _selected;
            set { if (SetProperty(ref _selected, value)) { OnPropertyChanged(nameof(IsEditMode)); SyncTimeText(); } }
        }

        public bool IsEditMode => Selected != null && Selected.JadwalId > 0;

        private string _jamMulaiText = "16:00";
        public string JamMulaiText { get => _jamMulaiText; set => SetProperty(ref _jamMulaiText, value); }

        private string _jamSelesaiText = "18:00";
        public string JamSelesaiText { get => _jamSelesaiText; set => SetProperty(ref _jamSelesaiText, value); }

        public ICommand NewCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand DeleteCommand { get; }

        public JadwalViewModel()
        {
            NewCommand = new RelayCommand(_ => Selected = new Jadwal());
            SaveCommand = new RelayCommand(_ => Save());
            DeleteCommand = new RelayCommand(_ => Delete());
            LoadData();
        }

        public void LoadData()
        {
            Data = new ObservableCollection<Jadwal>(_repo.GetAll());
            KelompokList = new ObservableCollection<Kelompok>(_kelompokRepo.GetAll());
            IsEmpty = Data.Count == 0;
        }

        private void SyncTimeText()
        {
            JamMulaiText = (Selected != null && Selected.JadwalId > 0) ? Selected.JamMulaiText : "16:00";
            JamSelesaiText = (Selected != null && Selected.JadwalId > 0) ? Selected.JamSelesaiText : "18:00";
        }

        private void Save()
        {
            if (Selected == null) return;
            if (Selected.KelompokId == 0) { MessageBoxHelper.ShowError("Kelompok wajib dipilih."); return; }
            if (string.IsNullOrWhiteSpace(Selected.Hari)) { MessageBoxHelper.ShowError("Hari wajib dipilih."); return; }
            if (!TimeSpan.TryParse(JamMulaiText, CultureInfo.InvariantCulture, out TimeSpan mulai)) { MessageBoxHelper.ShowError("Format jam mulai tidak valid."); return; }
            if (!TimeSpan.TryParse(JamSelesaiText, CultureInfo.InvariantCulture, out TimeSpan selesai)) { MessageBoxHelper.ShowError("Format jam selesai tidak valid."); return; }
            if (selesai <= mulai) { MessageBoxHelper.ShowError("Jam selesai harus setelah jam mulai."); return; }

            Selected.JamMulai = mulai;
            Selected.JamSelesai = selesai;

            try
            {
                if (IsEditMode) _repo.Update(Selected); else _repo.Insert(Selected);
                MessageBoxHelper.ShowSuccess(IsEditMode ? "Data berhasil diperbarui." : "Data berhasil ditambahkan.");
                Selected = new Jadwal();
                LoadData();
            }
            catch (SqlException) { MessageBoxHelper.ShowError("Terjadi kesalahan saat menyimpan data."); }
        }

        private void Delete()
        {
            if (!IsEditMode) return;
            if (!MessageBoxHelper.Confirm($"Hapus jadwal {Selected.NamaKelompok} hari {Selected.Hari}?")) return;
            try
            {
                _repo.Delete(Selected.JadwalId);
                MessageBoxHelper.ShowSuccess("Data berhasil dihapus.");
                Selected = new Jadwal();
                LoadData();
            }
            catch (SqlException) { MessageBoxHelper.ShowError("Data tidak dapat dihapus karena masih memiliki sesi latihan."); }
        }
    }
}