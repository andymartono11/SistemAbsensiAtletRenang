using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class KelompokViewModel : ViewModelBase
    {
        private readonly KelompokRepository _repo = new KelompokRepository();

        private ObservableCollection<Kelompok> _data = new ObservableCollection<Kelompok>();
        public ObservableCollection<Kelompok> Data { get => _data; set => SetProperty(ref _data, value); }

        private bool _isEmpty;
        public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

        private Kelompok _selected = new Kelompok();
        public Kelompok Selected
        {
            get => _selected;
            set { if (SetProperty(ref _selected, value)) OnPropertyChanged(nameof(IsEditMode)); }
        }

        public bool IsEditMode => Selected != null && Selected.KelompokId > 0;

        public ICommand NewCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand DeleteCommand { get; }

        public KelompokViewModel()
        {
            NewCommand = new RelayCommand(_ => Selected = new Kelompok());
            SaveCommand = new RelayCommand(_ => Save());
            DeleteCommand = new RelayCommand(_ => Delete());
            LoadData();
        }

        public void LoadData()
        {
            Data = new ObservableCollection<Kelompok>(_repo.GetAll());
            IsEmpty = Data.Count == 0;
        }

        private void Save()
        {
            if (Selected == null) return;
            if (string.IsNullOrWhiteSpace(Selected.NamaKelompok)) { MessageBoxHelper.ShowError("Nama kelompok wajib diisi."); return; }
            try
            {
                if (IsEditMode) _repo.Update(Selected); else _repo.Insert(Selected);
                MessageBoxHelper.ShowSuccess(IsEditMode ? "Data berhasil diperbarui." : "Data berhasil ditambahkan.");
                Selected = new Kelompok();
                LoadData();
            }
            catch (SqlException) { MessageBoxHelper.ShowError("Terjadi kesalahan saat menyimpan data."); }
        }

        private void Delete()
        {
            if (!IsEditMode) return;
            if (!MessageBoxHelper.Confirm($"Hapus kelompok '{Selected.NamaKelompok}'?")) return;
            try
            {
                _repo.Delete(Selected.KelompokId);
                MessageBoxHelper.ShowSuccess("Data berhasil dihapus.");
                Selected = new Kelompok();
                LoadData();
            }
            catch (SqlException) { MessageBoxHelper.ShowError("Data tidak dapat dihapus karena masih digunakan oleh atlet atau jadwal."); }
        }
    }
}