using System;
using System.Windows.Input;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Models;
using SwimmingAttendance.Services;

namespace SwimmingAttendance.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        public NavigationService Navigation { get; } = new NavigationService();

        public User CurrentUser { get; }
        public string HeaderTitle => $"Selamat Datang, {CurrentUser.Nama}";

        public event Action? LogoutRequested;

        public ICommand LogoutCommand { get; }
        public ICommand NavigateToDashboardCommand { get; }
        public ICommand NavigateToAbsensiCommand { get; }
        public ICommand NavigateToAtletCommand { get; }
        public ICommand NavigateToKelompokCommand { get; }
        public ICommand NavigateToJadwalCommand { get; }
        public ICommand NavigateToRekapCommand { get; }
        public ICommand NavigateToRiwayatCommand { get; }

        public MainViewModel(User currentUser)
        {
            CurrentUser = currentUser;

            LogoutCommand = new RelayCommand(_ => LogoutRequested?.Invoke());
            NavigateToDashboardCommand = new RelayCommand(_ => BukaDashboard());
            NavigateToAbsensiCommand = new RelayCommand(_ => Navigation.NavigateTo<AbsensiViewModel>());
            NavigateToAtletCommand = new RelayCommand(_ => Navigation.NavigateTo<AtletViewModel>());
            NavigateToKelompokCommand = new RelayCommand(_ => Navigation.NavigateTo<KelompokViewModel>());
            NavigateToJadwalCommand = new RelayCommand(_ => Navigation.NavigateTo<JadwalViewModel>());
            NavigateToRekapCommand = new RelayCommand(_ => Navigation.NavigateTo<RekapViewModel>());
            NavigateToRiwayatCommand = new RelayCommand(_ => Navigation.NavigateTo<RiwayatViewModel>());

            BukaDashboard();
        }

        private void BukaDashboard()
        {
            Navigation.NavigateTo<DashboardViewModel>(vm => vm.RequestIsiAbsensi = BukaAbsensiUntuk);
        }

        // Dipanggil dari tombol "Isi Absensi" di card jadwal dashboard
        private void BukaAbsensiUntuk(Jadwal jadwal)
        {
            Navigation.NavigateTo<AbsensiViewModel>(vm =>
            {
                vm.TanggalAbsensi = DateTime.Today;
                foreach (var j in vm.JadwalList)
                {
                    if (j.JadwalId == jadwal.JadwalId) vm.SelectedJadwal = j;
                }
                vm.LoadSesiCommand.Execute(null);
            });
        }
    }
}