using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class RekapViewModel : ViewModelBase
    {
        private readonly RekapRepository _repo = new RekapRepository();
        private readonly KelompokRepository _kelompokRepo = new KelompokRepository();

        private ObservableCollection<Kelompok> _kelompokList = new ObservableCollection<Kelompok>();
        public ObservableCollection<Kelompok> KelompokList
        {
            get => _kelompokList;
            set => SetProperty(ref _kelompokList, value);
        }

        private Kelompok? _selectedKelompok;
        public Kelompok? SelectedKelompok
        {
            get => _selectedKelompok;
            set { if (SetProperty(ref _selectedKelompok, value)) LoadData(); }
        }

        public List<string> BulanOptions { get; } = TanggalHelper.NamaBulan;

        private string _selectedBulan;
        public string SelectedBulan
        {
            get => _selectedBulan;
            set { if (SetProperty(ref _selectedBulan, value)) LoadData(); }
        }

        private List<int> _tahunOptions = new List<int>();
        public List<int> TahunOptions
        {
            get => _tahunOptions;
            set => SetProperty(ref _tahunOptions, value);
        }

        private int _selectedTahun;
        public int SelectedTahun
        {
            get => _selectedTahun;
            set { if (SetProperty(ref _selectedTahun, value)) LoadData(); }
        }

        private ObservableCollection<RekapItem> _data = new ObservableCollection<RekapItem>();
        public ObservableCollection<RekapItem> Data
        {
            get => _data;
            set => SetProperty(ref _data, value);
        }

        private bool _isEmpty;
        public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

        public RekapViewModel()
        {
            KelompokList = new ObservableCollection<Kelompok>(_kelompokRepo.GetAll());

            TahunOptions = _repo.GetTahunList();
            if (!TahunOptions.Contains(DateTime.Today.Year)) TahunOptions.Insert(0, DateTime.Today.Year);

            _selectedBulan = TanggalHelper.NamaBulan[DateTime.Today.Month - 1];
            _selectedTahun = DateTime.Today.Year;

            LoadData();
        }

        public void LoadData()
        {
            if (SelectedKelompok == null)
            {
                Data = new ObservableCollection<RekapItem>();
                IsEmpty = true;
                return;
            }

            int bulan = TanggalHelper.BulanDariNama(SelectedBulan) ?? DateTime.Today.Month;

            try
            {
                Data = new ObservableCollection<RekapItem>(
                    _repo.GetRekap(SelectedKelompok.KelompokId, bulan, SelectedTahun));
            }
            catch (SqlException)
            {
                MessageBoxHelper.ShowError("Gagal memuat data rekap.");
            }

            IsEmpty = Data.Count == 0;
        }
    }
}