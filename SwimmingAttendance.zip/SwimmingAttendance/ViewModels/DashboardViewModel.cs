using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using SwimmingAttendance.Commands;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;
using SwimmingAttendance.Repositories;

namespace SwimmingAttendance.ViewModels
{
    public class DashboardViewModel : ViewModelBase
    {
        private readonly DashboardRepository _repo = new DashboardRepository();

        private int _totalAtletAktif;
        public int TotalAtletAktif { get => _totalAtletAktif; set => SetProperty(ref _totalAtletAktif, value); }

        private int _latihanHariIni;
        public int LatihanHariIni { get => _latihanHariIni; set => SetProperty(ref _latihanHariIni, value); }

        private int _hadirHariIni;
        public int HadirHariIni { get => _hadirHariIni; set => SetProperty(ref _hadirHariIni, value); }

        private int _tidakHadirHariIni;
        public int TidakHadirHariIni { get => _tidakHadirHariIni; set => SetProperty(ref _tidakHadirHariIni, value); }

        private ObservableCollection<Jadwal> _jadwalHariIni = new ObservableCollection<Jadwal>();
        public ObservableCollection<Jadwal> JadwalHariIni
        {
            get => _jadwalHariIni;
            set => SetProperty(ref _jadwalHariIni, value);
        }

        private bool _isEmptyJadwal;
        public bool IsEmptyJadwal { get => _isEmptyJadwal; set => SetProperty(ref _isEmptyJadwal, value); }

        // Di-set oleh MainViewModel untuk navigasi ke halaman absensi
        public Action<Jadwal>? RequestIsiAbsensi { get; set; }

        public ICommand IsiAbsensiCommand { get; }

        public DashboardViewModel()
        {
            IsiAbsensiCommand = new RelayCommand(p =>
            {
                if (p is Jadwal j) RequestIsiAbsensi?.Invoke(j);
            });
            LoadData();
        }

        public void LoadData()
        {
            string hari = TanggalHelper.GetNamaHari(DateTime.Today);

            TotalAtletAktif = _repo.GetTotalAtletAktif();
            LatihanHariIni = _repo.GetJumlahLatihanHariIni(hari);
            HadirHariIni = _repo.GetHadirHariIni(DateTime.Today);
            TidakHadirHariIni = _repo.GetTidakHadirHariIni(DateTime.Today);

            JadwalHariIni = new ObservableCollection<Jadwal>(_repo.GetJadwalHariIni(hari));
            IsEmptyJadwal = JadwalHariIni.Count == 0;
        }
    }
}