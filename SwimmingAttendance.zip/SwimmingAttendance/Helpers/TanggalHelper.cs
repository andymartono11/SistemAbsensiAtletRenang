using System;
using System.Collections.Generic;

namespace SwimmingAttendance.Helpers
{
    public static class TanggalHelper
    {
        public static string GetNamaHari(DateTime date)
        {
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Monday: return "Senin";
                case DayOfWeek.Tuesday: return "Selasa";
                case DayOfWeek.Wednesday: return "Rabu";
                case DayOfWeek.Thursday: return "Kamis";
                case DayOfWeek.Friday: return "Jumat";
                case DayOfWeek.Saturday: return "Sabtu";
                default: return "Minggu";
            }
        }

        public static List<string> NamaBulan { get; } = new List<string>
        {
            "Januari", "Februari", "Maret", "April", "Mei", "Juni",
            "Juli", "Agustus", "September", "Oktober", "November", "Desember"
        };

        public static int? BulanDariNama(string? nama)
        {
            int idx = NamaBulan.IndexOf(nama ?? "");
            return idx >= 0 ? idx + 1 : (int?)null;
        }
    }
}