using System.Windows;

namespace SwimmingAttendance.Helpers
{
    public static class MessageBoxHelper
    {
        public static void ShowSuccess(string message)
            => MessageBox.Show(message, "Sukses", MessageBoxButton.OK, MessageBoxImage.Information);

        public static void ShowError(string message)
            => MessageBox.Show(message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);

        public static bool Confirm(string message)
            => MessageBox.Show(message, "Konfirmasi", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
    }
}