// Helpers/DatabaseHelper.cs
using Microsoft.Data.SqlClient;

namespace SwimmingAttendance.Helpers
{
    /// <summary>
    /// Satu-satunya tempat yang menyimpan connection string.
    /// Semua repository nanti mengambil koneksi dari sini.
    /// </summary>
    public static class DatabaseHelper
    {
        // Jika Anda memakai SQL Server penuh (bukan LocalDB),
        // ganti bagian Server= dengan nama instance Anda, contoh: Server=.\\SQLEXPRESS
        private static readonly string _connectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=SwimmingAttendanceDB;Trusted_Connection=True;TrustServerCertificate=True;";

        public static SqlConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }

        /// <summary>
        /// Mengecek apakah database bisa dihubungi. Tidak melempar exception ke luar.
        /// </summary>
        public static bool TestConnection(out string errorMessage)
        {
            errorMessage = string.Empty;
            try
            {
                using var connection = CreateConnection();
                connection.Open();
                return true;
            }
            catch (SqlException ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }
    }
}