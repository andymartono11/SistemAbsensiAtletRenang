using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class RekapRepository
    {
        public List<RekapItem> GetRekap(int kelompokId, int bulan, int tahun)
        {
            var list = new List<RekapItem>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();

            const string sql = @"SELECT a.AtletId, a.Nama,
                                        SUM(CASE WHEN ab.Status = 'Hadir' THEN 1 ELSE 0 END) AS Hadir,
                                        SUM(CASE WHEN ab.Status = 'Izin'  THEN 1 ELSE 0 END) AS Izin,
                                        SUM(CASE WHEN ab.Status = 'Sakit' THEN 1 ELSE 0 END) AS Sakit,
                                        SUM(CASE WHEN ab.Status = 'Alpha' THEN 1 ELSE 0 END) AS Alpha
                                 FROM Atlet a
                                 LEFT JOIN Absensi ab ON a.AtletId = ab.AtletId
                                 LEFT JOIN SesiLatihan s ON ab.SesiId = s.SesiId
                                 WHERE a.KelompokId = @KelompokId AND a.IsActive = 1
                                   AND (ab.AbsensiId IS NULL OR (MONTH(s.Tanggal) = @Bulan AND YEAR(s.Tanggal) = @Tahun))
                                 GROUP BY a.AtletId, a.Nama
                                 ORDER BY a.Nama";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@KelompokId", kelompokId);
            cmd.Parameters.AddWithValue("@Bulan", bulan);
            cmd.Parameters.AddWithValue("@Tahun", tahun);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new RekapItem
                {
                    AtletId = (int)reader["AtletId"],
                    Nama = (string)reader["Nama"],
                    Hadir = reader["Hadir"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Hadir"]),
                    Izin = reader["Izin"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Izin"]),
                    Sakit = reader["Sakit"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Sakit"]),
                    Alpha = reader["Alpha"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Alpha"])
                });
            }
            return list;
        }

        public List<int> GetTahunList()
        {
            var list = new List<int>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT DISTINCT YEAR(Tanggal) FROM SesiLatihan ORDER BY 1 DESC", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read()) list.Add(reader.GetInt32(0));
            return list;
        }
    }
}