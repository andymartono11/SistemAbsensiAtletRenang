using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class AbsensiRepository
    {
        /// <summary>
        /// Ambil jadwal aktif (untuk dropdown pilih sesi).
        /// </summary>
        public List<Jadwal> GetJadwalAktif()
        {
            var list = new List<Jadwal>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"SELECT j.JadwalId, j.KelompokId, j.Hari, j.JamMulai, j.JamSelesai, k.NamaKelompok
                                 FROM Jadwal j
                                 INNER JOIN Kelompok k ON j.KelompokId = k.KelompokId
                                 WHERE j.IsActive = 1 AND k.IsActive = 1
                                 ORDER BY k.NamaKelompok, j.Hari, j.JamMulai";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Jadwal
                {
                    JadwalId = (int)reader["JadwalId"],
                    KelompokId = (int)reader["KelompokId"],
                    Hari = (string)reader["Hari"],
                    JamMulai = (TimeSpan)reader["JamMulai"],
                    JamSelesai = (TimeSpan)reader["JamSelesai"],
                    NamaKelompok = (string)reader["NamaKelompok"]
                });
            }
            return list;
        }

        /// <summary>
        /// Ambil atau buat sesi latihan untuk tanggal + jadwal tertentu.
        /// Jika belum ada, otomatis INSERT.
        /// </summary>
        public SesiLatihan GetOrCreateSesi(int jadwalId, DateTime tanggal)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();

            // Cek apakah sesi sudah ada
            const string selectSql = @"SELECT s.SesiId, s.JadwalId, s.Tanggal, j.KelompokId, j.Hari, j.JamMulai, j.JamSelesai, k.NamaKelompok
                                       FROM SesiLatihan s
                                       INNER JOIN Jadwal j ON s.JadwalId = j.JadwalId
                                       INNER JOIN Kelompok k ON j.KelompokId = k.KelompokId
                                       WHERE s.JadwalId = @JadwalId AND s.Tanggal = @Tanggal";
            using var selectCmd = new SqlCommand(selectSql, conn);
            selectCmd.Parameters.AddWithValue("@JadwalId", jadwalId);
            selectCmd.Parameters.AddWithValue("@Tanggal", tanggal.Date);

            using var reader = selectCmd.ExecuteReader();
            if (reader.Read())
            {
                return new SesiLatihan
                {
                    SesiId = (int)reader["SesiId"],
                    JadwalId = (int)reader["JadwalId"],
                    Tanggal = (DateTime)reader["Tanggal"],
                    NamaKelompok = (string)reader["NamaKelompok"],
                    Hari = (string)reader["Hari"],
                    JamMulai = (TimeSpan)reader["JamMulai"],
                    JamSelesai = (TimeSpan)reader["JamSelesai"]
                };
            }
            reader.Close();

            // Belum ada, INSERT baru
            const string insertSql = @"INSERT INTO SesiLatihan (JadwalId, Tanggal) VALUES (@JadwalId, @Tanggal);
                                       SELECT SCOPE_IDENTITY();";
            using var insertCmd = new SqlCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@JadwalId", jadwalId);
            insertCmd.Parameters.AddWithValue("@Tanggal", tanggal.Date);
            var sesiId = Convert.ToInt32(insertCmd.ExecuteScalar());

            // Ambil data lengkap sesi baru
            const string getSql = @"SELECT s.SesiId, s.JadwalId, s.Tanggal, j.Hari, j.JamMulai, j.JamSelesai, k.NamaKelompok
                                    FROM SesiLatihan s
                                    INNER JOIN Jadwal j ON s.JadwalId = j.JadwalId
                                    INNER JOIN Kelompok k ON j.KelompokId = k.KelompokId
                                    WHERE s.SesiId = @SesiId";
            using var getCmd = new SqlCommand(getSql, conn);
            getCmd.Parameters.AddWithValue("@SesiId", sesiId);
            using var reader2 = getCmd.ExecuteReader();
            reader2.Read();
            return new SesiLatihan
            {
                SesiId = sesiId,
                JadwalId = jadwalId,
                Tanggal = tanggal.Date,
                NamaKelompok = (string)reader2["NamaKelompok"],
                Hari = (string)reader2["Hari"],
                JamMulai = (TimeSpan)reader2["JamMulai"],
                JamSelesai = (TimeSpan)reader2["JamSelesai"]
            };
        }

        /// <summary>
        /// Ambil daftar atlet aktif dari suatu kelompok + data absensi mereka (jika ada) untuk sesi tertentu.
        /// </summary>
        public List<AbsensiItem> GetAtletDenganAbsensi(int kelompokId, int sesiId)
        {
            var list = new List<AbsensiItem>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();

            const string sql = @"SELECT a.AtletId, a.Nama,
                                        abs.AbsensiId, abs.Status, abs.Catatan
                                 FROM Atlet a
                                 LEFT JOIN Absensi abs ON a.AtletId = abs.AtletId AND abs.SesiId = @SesiId
                                 WHERE a.KelompokId = @KelompokId AND a.IsActive = 1
                                 ORDER BY a.Nama";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@KelompokId", kelompokId);
            cmd.Parameters.AddWithValue("@SesiId", sesiId);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new AbsensiItem
                {
                    AtletId = (int)reader["AtletId"],
                    NamaAtlet = (string)reader["Nama"],
                    AbsensiId = reader["AbsensiId"] == DBNull.Value ? (int?)null : (int)reader["AbsensiId"],
                    Status = reader["Status"] == DBNull.Value ? "Hadir" : (string)reader["Status"],
                    Catatan = reader["Catatan"] == DBNull.Value ? null : (string)reader["Catatan"]
                });
            }
            return list;
        }

        /// <summary>
        /// Simpan banyak absensi sekaligus dalam satu transaksi.
        /// UPDATE jika AbsensiId sudah ada, INSERT jika belum.
        /// </summary>
        public void SimpanAbsensi(int sesiId, List<AbsensiItem> items)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            using var transaction = conn.BeginTransaction();

            try
            {
                foreach (var item in items)
                {
                    if (item.AbsensiId.HasValue)
                    {
                        // UPDATE
                        const string updateSql = @"UPDATE Absensi SET Status=@Status, Catatan=@Catatan WHERE AbsensiId=@Id";
                        using var cmd = new SqlCommand(updateSql, conn, transaction);
                        cmd.Parameters.AddWithValue("@Id", item.AbsensiId.Value);
                        cmd.Parameters.AddWithValue("@Status", item.Status);
                        cmd.Parameters.AddWithValue("@Catatan", (object?)item.Catatan ?? DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        // INSERT
                        const string insertSql = @"INSERT INTO Absensi (SesiId, AtletId, Status, Catatan) VALUES (@SesiId, @AtletId, @Status, @Catatan)";
                        using var cmd = new SqlCommand(insertSql, conn, transaction);
                        cmd.Parameters.AddWithValue("@SesiId", sesiId);
                        cmd.Parameters.AddWithValue("@AtletId", item.AtletId);
                        cmd.Parameters.AddWithValue("@Status", item.Status);
                        cmd.Parameters.AddWithValue("@Catatan", (object?)item.Catatan ?? DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }
                }
                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }
    }
}