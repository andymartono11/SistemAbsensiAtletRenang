using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class RiwayatRepository
    {
        public List<RiwayatAbsensi> GetRiwayat(int atletId, int? bulan, int? tahun)
        {
            var list = new List<RiwayatAbsensi>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();

            const string sql = @"SELECT s.Tanggal, k.NamaKelompok, j.JamMulai, j.JamSelesai, a.Status, a.Catatan
                                 FROM Absensi a
                                 INNER JOIN SesiLatihan s ON a.SesiId = s.SesiId
                                 INNER JOIN Jadwal j ON s.JadwalId = j.JadwalId
                                 INNER JOIN Kelompok k ON j.KelompokId = k.KelompokId
                                 WHERE a.AtletId = @AtletId
                                   AND (@Bulan IS NULL OR MONTH(s.Tanggal) = @Bulan)
                                   AND (@Tahun IS NULL OR YEAR(s.Tanggal) = @Tahun)
                                 ORDER BY s.Tanggal DESC";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@AtletId", atletId);
            cmd.Parameters.AddWithValue("@Bulan", (object?)bulan ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Tahun", (object?)tahun ?? DBNull.Value);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var mulai = (TimeSpan)reader["JamMulai"];
                var selesai = (TimeSpan)reader["JamSelesai"];
                list.Add(new RiwayatAbsensi
                {
                    Tanggal = (DateTime)reader["Tanggal"],
                    NamaKelompok = (string)reader["NamaKelompok"],
                    JamLatihan = $"{mulai:hh\\:mm} - {selesai:hh\\:mm}",
                    Status = (string)reader["Status"],
                    Catatan = reader["Catatan"] == DBNull.Value ? null : (string)reader["Catatan"]
                });
            }
            return list;
        }

        public List<int> GetTahunList()
        {
            var list = new List<int>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT DISTINCT YEAR(Tanggal) FROM SesiLatihan ORDER BY 1 DESC", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read()) list.Add(reader.GetInt32(0));
            return list;
        }
    }
}