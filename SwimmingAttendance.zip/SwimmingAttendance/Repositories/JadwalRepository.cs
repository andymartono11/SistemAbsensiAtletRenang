using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class JadwalRepository
    {
        public List<Jadwal> GetAll()
        {
            var list = new List<Jadwal>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"SELECT j.JadwalId, j.KelompokId, j.Hari, j.JamMulai, j.JamSelesai, j.IsActive, k.NamaKelompok
                                 FROM Jadwal j
                                 INNER JOIN Kelompok k ON j.KelompokId = k.KelompokId
                                 WHERE j.IsActive = 1
                                 ORDER BY j.Hari, j.JamMulai";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Jadwal
                {
                    JadwalId = (int)reader["JadwalId"],
                    KelompokId = (int)reader["KelompokId"],
                    Hari = (string)reader["Hari"],
                    JamMulai = (TimeSpan)reader["JamMulai"],
                    JamSelesai = (TimeSpan)reader["JamSelesai"],
                    IsActive = (bool)reader["IsActive"],
                    NamaKelompok = (string)reader["NamaKelompok"]
                });
            }
            return list;
        }

        public void Insert(Jadwal j)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"INSERT INTO Jadwal (KelompokId, Hari, JamMulai, JamSelesai, IsActive)
                                 VALUES (@KelompokId, @Hari, @Mulai, @Selesai, @IsActive)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@KelompokId", j.KelompokId);
            cmd.Parameters.AddWithValue("@Hari", j.Hari);
            cmd.Parameters.AddWithValue("@Mulai", j.JamMulai);
            cmd.Parameters.AddWithValue("@Selesai", j.JamSelesai);
            cmd.Parameters.AddWithValue("@IsActive", j.IsActive);
            cmd.ExecuteNonQuery();
        }

        public void Update(Jadwal j)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"UPDATE Jadwal SET KelompokId=@KelompokId, Hari=@Hari, JamMulai=@Mulai,
                                 JamSelesai=@Selesai, IsActive=@IsActive WHERE JadwalId=@Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", j.JadwalId);
            cmd.Parameters.AddWithValue("@KelompokId", j.KelompokId);
            cmd.Parameters.AddWithValue("@Hari", j.Hari);
            cmd.Parameters.AddWithValue("@Mulai", j.JamMulai);
            cmd.Parameters.AddWithValue("@Selesai", j.JamSelesai);
            cmd.Parameters.AddWithValue("@IsActive", j.IsActive);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = "DELETE FROM Jadwal WHERE JadwalId=@Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.ExecuteNonQuery();
        }
    }
}