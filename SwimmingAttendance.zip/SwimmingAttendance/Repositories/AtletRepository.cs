using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class AtletRepository
    {
        // Mendukung pencarian nama + filter kelompok + filter status
        public List<Atlet> GetAll(string? searchNama, int? filterKelompokId, bool? filterAktif)
        {
            var list = new List<Atlet>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();

            var sql = @"SELECT a.AtletId, a.Nama, a.TanggalLahir, a.KelompokId, a.NomorHP,
                               a.TanggalBergabung, a.IsActive, k.NamaKelompok
                        FROM Atlet a
                        INNER JOIN Kelompok k ON a.KelompokId = k.KelompokId
                        WHERE 1=1";

            if (!string.IsNullOrWhiteSpace(searchNama)) sql += " AND a.Nama LIKE @Nama";
            if (filterKelompokId.HasValue)              sql += " AND a.KelompokId = @KelompokId";
            if (filterAktif.HasValue)                   sql += " AND a.IsActive = @Aktif";
            sql += " ORDER BY a.Nama";

            using var cmd = new SqlCommand(sql, conn);
            if (!string.IsNullOrWhiteSpace(searchNama)) cmd.Parameters.AddWithValue("@Nama", "%" + searchNama.Trim() + "%");
            if (filterKelompokId.HasValue)              cmd.Parameters.AddWithValue("@KelompokId", filterKelompokId.Value);
            if (filterAktif.HasValue)                   cmd.Parameters.AddWithValue("@Aktif", filterAktif.Value);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Atlet
                {
                    AtletId = (int)reader["AtletId"],
                    Nama = (string)reader["Nama"],
                    TanggalLahir = (DateTime)reader["TanggalLahir"],
                    KelompokId = (int)reader["KelompokId"],
                    NomorHP = reader["NomorHP"] as string,
                    TanggalBergabung = (DateTime)reader["TanggalBergabung"],
                    IsActive = (bool)reader["IsActive"],
                    NamaKelompok = (string)reader["NamaKelompok"]
                });
            }
            return list;
        }

        public void Insert(Atlet a)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"INSERT INTO Atlet (Nama, TanggalLahir, KelompokId, NomorHP, TanggalBergabung, IsActive)
                                 VALUES (@Nama, @TglLahir, @KelompokId, @HP, @TglGabung, @IsActive)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Nama", a.Nama);
            cmd.Parameters.AddWithValue("@TglLahir", a.TanggalLahir.Date);
            cmd.Parameters.AddWithValue("@KelompokId", a.KelompokId);
            cmd.Parameters.AddWithValue("@HP", (object?)a.NomorHP ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TglGabung", a.TanggalBergabung.Date);
            cmd.Parameters.AddWithValue("@IsActive", a.IsActive);
            cmd.ExecuteNonQuery();
        }

        public void Update(Atlet a)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"UPDATE Atlet SET Nama=@Nama, TanggalLahir=@TglLahir, KelompokId=@KelompokId,
                                 NomorHP=@HP, TanggalBergabung=@TglGabung, IsActive=@IsActive WHERE AtletId=@Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", a.AtletId);
            cmd.Parameters.AddWithValue("@Nama", a.Nama);
            cmd.Parameters.AddWithValue("@TglLahir", a.TanggalLahir.Date);
            cmd.Parameters.AddWithValue("@KelompokId", a.KelompokId);
            cmd.Parameters.AddWithValue("@HP", (object?)a.NomorHP ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TglGabung", a.TanggalBergabung.Date);
            cmd.Parameters.AddWithValue("@IsActive", a.IsActive);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = "DELETE FROM Atlet WHERE AtletId=@Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.ExecuteNonQuery();
        }
    }
}