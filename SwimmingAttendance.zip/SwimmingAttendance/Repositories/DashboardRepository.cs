using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class DashboardRepository
    {
        public int GetTotalAtletAktif()
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT COUNT(*) FROM Atlet WHERE IsActive = 1", conn);
            return (int)cmd.ExecuteScalar();
        }

        public int GetJumlahLatihanHariIni(string namaHari)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT COUNT(*) FROM Jadwal WHERE IsActive = 1 AND Hari = @Hari", conn);
            cmd.Parameters.AddWithValue("@Hari", namaHari);
            return (int)cmd.ExecuteScalar();
        }

        public int GetHadirHariIni(DateTime tanggal)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"SELECT COUNT(*) FROM Absensi a
                                 INNER JOIN SesiLatihan s ON a.SesiId = s.SesiId
                                 WHERE s.Tanggal = @Tanggal AND a.Status = 'Hadir'";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Tanggal", tanggal.Date);
            return (int)cmd.ExecuteScalar();
        }

        public int GetTidakHadirHariIni(DateTime tanggal)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"SELECT COUNT(*) FROM Absensi a
                                 INNER JOIN SesiLatihan s ON a.SesiId = s.SesiId
                                 WHERE s.Tanggal = @Tanggal AND a.Status IN ('Izin','Sakit','Alpha')";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Tanggal", tanggal.Date);
            return (int)cmd.ExecuteScalar();
        }

        public List<Jadwal> GetJadwalHariIni(string namaHari)
        {
            var list = new List<Jadwal>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = @"SELECT j.JadwalId, j.KelompokId, j.Hari, j.JamMulai, j.JamSelesai, k.NamaKelompok
                                 FROM Jadwal j
                                 INNER JOIN Kelompok k ON j.KelompokId = k.KelompokId
                                 WHERE j.IsActive = 1 AND k.IsActive = 1 AND j.Hari = @Hari
                                 ORDER BY j.JamMulai";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Hari", namaHari);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Jadwal
                {
                    JadwalId = (int)reader["JadwalId"],
                    KelompokId = (int)reader["KelompokId"],
                    Hari = (string)reader["Hari"],
                    JamMulai = (TimeSpan)reader["JamMulai"],
                    JamSelesai = (TimeSpan)reader["JamSelesai"],
                    NamaKelompok = (string)reader["NamaKelompok"]
                });
            }
            return list;
        }
    }
}