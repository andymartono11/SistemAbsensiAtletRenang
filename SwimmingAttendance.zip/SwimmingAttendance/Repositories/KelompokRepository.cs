using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Repositories
{
    public class KelompokRepository
    {
        public List<Kelompok> GetAll()
        {
            var list = new List<Kelompok>();
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = "SELECT KelompokId, NamaKelompok, Deskripsi, IsActive FROM Kelompok ORDER BY NamaKelompok";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Kelompok
                {
                    KelompokId = (int)reader["KelompokId"],
                    NamaKelompok = (string)reader["NamaKelompok"],
                    Deskripsi = reader["Deskripsi"] as string,
                    IsActive = (bool)reader["IsActive"]
                });
            }
            return list;
        }

        public void Insert(Kelompok k)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = "INSERT INTO Kelompok (NamaKelompok, Deskripsi, IsActive) VALUES (@Nama, @Deskripsi, @IsActive)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Nama", k.NamaKelompok);
            cmd.Parameters.AddWithValue("@Deskripsi", (object?)k.Deskripsi ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@IsActive", k.IsActive);
            cmd.ExecuteNonQuery();
        }

        public void Update(Kelompok k)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = "UPDATE Kelompok SET NamaKelompok=@Nama, Deskripsi=@Deskripsi, IsActive=@IsActive WHERE KelompokId=@Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", k.KelompokId);
            cmd.Parameters.AddWithValue("@Nama", k.NamaKelompok);
            cmd.Parameters.AddWithValue("@Deskripsi", (object?)k.Deskripsi ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@IsActive", k.IsActive);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var conn = DatabaseHelper.CreateConnection();
            conn.Open();
            const string sql = "DELETE FROM Kelompok WHERE KelompokId=@Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.ExecuteNonQuery();
        }
    }
}