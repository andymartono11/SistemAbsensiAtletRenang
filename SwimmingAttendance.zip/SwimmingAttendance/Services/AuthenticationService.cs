// Services/AuthenticationService.cs
using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Models;

namespace SwimmingAttendance.Services
{
    public class AuthenticationService
    {
        /// <summary>
        /// Memverifikasi username & password ke tabel Users.
        /// Mengembalikan objek User jika berhasil, atau null jika gagal.
        /// </summary>
        public User? Login(string username, string password, out string errorMessage)
        {
            errorMessage = string.Empty;

            try
            {
                using var connection = DatabaseHelper.CreateConnection();
                connection.Open();

                // Parameterized query: input user TIDAK PERNAH dirakit ke string SQL
                const string sql = @"SELECT UserId, Username, PasswordHash, Nama, Role, IsActive
                                     FROM Users
                                     WHERE Username = @Username";

                using var command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Username", username);

                using var reader = command.ExecuteReader();
                if (!reader.Read())
                {
                    errorMessage = "Username atau password salah.";
                    return null;
                }

                var storedHash = (byte[])reader["PasswordHash"];
                var isActive = (bool)reader["IsActive"];

                // Bandingkan hash SHA-256 dari input dengan hash di database
                if (!CryptographicOperations.FixedTimeEquals(ComputeHash(password), storedHash))
                {
                    errorMessage = "Username atau password salah.";
                    return null;
                }

                if (!isActive)
                {
                    errorMessage = "Akun Anda tidak aktif. Hubungi administrator.";
                    return null;
                }

                return new User
                {
                    UserId = (int)reader["UserId"],
                    Username = (string)reader["Username"],
                    Nama = (string)reader["Nama"],
                    Role = (string)reader["Role"],
                    IsActive = isActive
                };
            }
            catch (SqlException)
            {
                errorMessage = "Tidak dapat terhubung ke database. Silakan periksa koneksi.";
                return null;
            }
        }

        /// <summary>
        /// Hash SHA-256 — mekanisme yang sama dengan HASHBYTES('SHA2_256', ...) di SQL Server.
        /// </summary>
        public static byte[] ComputeHash(string password)
        {
            return SHA256.HashData(Encoding.Unicode.GetBytes(password));        
        }
    }
}