using System;
using SwimmingAttendance.ViewModels;

namespace SwimmingAttendance.Services
{
    public class NavigationService : ViewModelBase
    {
        private ViewModelBase? _currentView;
        public ViewModelBase? CurrentView
        {
            get => _currentView;
            private set => SetProperty(ref _currentView, value);
        }

        public void NavigateTo<TViewModel>() where TViewModel : ViewModelBase, new()
        {
            CurrentView = new TViewModel();
        }

        // Versi dengan konfigurasi: dipakai tombol "Isi Absensi" di dashboard
        public void NavigateTo<TViewModel>(Action<TViewModel> configure) where TViewModel : ViewModelBase, new()
        {
            var vm = new TViewModel();
            configure(vm);
            CurrentView = vm;
        }
    }
}