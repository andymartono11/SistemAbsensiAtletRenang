﻿// MainWindow.xaml.cs (TIMPA penuh dengan versi ini)
using System.Windows;
using SwimmingAttendance.Models;
using SwimmingAttendance.ViewModels;
using SwimmingAttendance.Views;

namespace SwimmingAttendance
{
    public partial class MainWindow : Window
    {
        public MainWindow(User user)
        {
            InitializeComponent();

            var viewModel = new MainViewModel(user);
            DataContext = viewModel;
            viewModel.LogoutRequested += OnLogoutRequested;
        }

        // Logout: tutup MainWindow, buka kembali Login
        private void OnLogoutRequested()
        {
            var loginView = new LoginView();
            loginView.Show();
            Close();
        }
    }
}