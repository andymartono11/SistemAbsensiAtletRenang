using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class JadwalView : UserControl
    {
        public JadwalView()
        {
            InitializeComponent();
        }
    }
}