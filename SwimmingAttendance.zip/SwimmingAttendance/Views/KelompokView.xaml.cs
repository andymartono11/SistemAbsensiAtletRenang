using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class KelompokView : UserControl
    {
        public KelompokView()
        {
            InitializeComponent();
        }
    }
}