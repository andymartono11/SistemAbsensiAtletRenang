// Views/LoginView.xaml.cs
using System.Windows;
using System.Windows.Controls;
using SwimmingAttendance.Models;
using SwimmingAttendance.ViewModels;

namespace SwimmingAttendance.Views
{
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();

            var viewModel = new LoginViewModel();
            DataContext = viewModel;
            viewModel.LoginSucceeded += OnLoginSucceeded;
        }

        // PasswordBox tidak bisa di-binding langsung, jadi diteruskan manual ke ViewModel
        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is LoginViewModel viewModel)
            {
                viewModel.Password = ((PasswordBox)sender).Password;
            }
        }

        // Login berhasil: buka MainWindow, tutup Login
        private void OnLoginSucceeded(User user)
        {
            var mainWindow = new MainWindow(user);
            mainWindow.Show();
            Close();
        }
    }
}