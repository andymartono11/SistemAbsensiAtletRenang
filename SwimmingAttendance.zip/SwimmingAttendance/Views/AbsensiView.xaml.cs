using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class AbsensiView : UserControl
    {
        public AbsensiView()
        {
            InitializeComponent();
        }
    }
}