using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class DashboardView : UserControl
    {
        public DashboardView()
        {
            InitializeComponent();
        }
    }
}