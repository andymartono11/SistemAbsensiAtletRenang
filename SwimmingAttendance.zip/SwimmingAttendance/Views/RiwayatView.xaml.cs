using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class RiwayatView : UserControl
    {
        public RiwayatView()
        {
            InitializeComponent();
        }
    }
}