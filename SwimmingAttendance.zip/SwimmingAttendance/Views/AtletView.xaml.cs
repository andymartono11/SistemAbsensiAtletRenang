using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class AtletView : UserControl
    {
        public AtletView()
        {
            InitializeComponent();
        }
    }
}