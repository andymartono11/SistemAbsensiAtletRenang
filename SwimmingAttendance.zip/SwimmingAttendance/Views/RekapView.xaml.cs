using System.Windows.Controls;

namespace SwimmingAttendance.Views
{
    public partial class RekapView : UserControl
    {
        public RekapView()
        {
            InitializeComponent();
        }
    }
}