﻿// App.xaml.cs
using System.Windows;
using SwimmingAttendance.Helpers;
using SwimmingAttendance.Views;

namespace SwimmingAttendance
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Cek koneksi database dulu (tidak crash jika gagal, hanya peringatan)
            if (!DatabaseHelper.TestConnection(out string errorMessage))
            {
                MessageBox.Show(
                    "Tidak dapat terhubung ke database. Silakan periksa koneksi.\n\nDetail teknis:\n" + errorMessage,
                    "Koneksi Database",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }

            // Aplikasi selalu mulai dari halaman login
            new LoginView().Show();
        }
    }
}